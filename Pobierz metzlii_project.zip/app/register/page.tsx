export default function RegisterPage() {
  return <div>Register Page (optional, handled by provider)</div>;
}
