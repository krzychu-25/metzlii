export default function LoginPage() {
  return <div>Login Page (NextAuth)</div>;
}
