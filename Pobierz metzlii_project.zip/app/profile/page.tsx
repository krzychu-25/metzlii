export default function ProfilePage() {
  return <div>Your profile (protected)</div>;
}
